# V170 verified all-PL snapshot — not real-time acceptance

Pinned source: v170_hls15, matching timing-closed 100 MHz BIT/XSA/ELF. All 117 exposed historical MVTec Tile development images were physically processed on PYNQ-Z2; integer scores and original-size masks are exact. Image decisions: 84/84 anomalies (17/17 cracks), 0/33 normal false alarms. This is not independent or general-material accuracy. Crack segmentation remains coarse (historical mean IoU about 0.067).

Measured fixed-frame PL auto-restart: 4.279494 FPS, one ARM start followed by 33 completed hardware frames. This is NOT continuous HDMI video and NOT the 10 FPS target. reports/verification.json binds source/model/build identities and all case hashes. all_117_board_raw.zip contains every raw hardware result and evidence file. Models and original photo URLs/SHA256 are recorded in model/; two original examples and actual overlays are included. unit_vectors/ contains the exact RTL input/reference files; the generator is pinned to local source commit ea70ad4.

PL performs the complete integer detector. ARM performs transport, CRC, start/stop and timing; PC decodes files, sends RGB, renders masks and stores evidence. No CPU/GPU detection fallback. Runtime needs only Pillow/NumPy. Vitis/Vivado 2025.2 rebuild source is included. Programming is volatile JTAG; no Flash writes.

From this folder: python source/scripts/texture_v170/program_board.py --hardware hardware --software software --out runtime/program_new
Then: python source/tools/fpga_texture_v170/board_client.py --model model --image examples/6621d769324f6e05d583835f/input.png --out runtime/case_new
PC Ethernet: 192.168.33.30/24; board: 192.168.33.10:9136. Use new output folders. Decode/transport/display are the only PC runtime work.

Original code is MIT; MVTec-derived models/photos/evidence retain CC BY-NC-SA 4.0, and vendor IP/upstream weights retain original terms. This engineering snapshot is not a final competition submission.
