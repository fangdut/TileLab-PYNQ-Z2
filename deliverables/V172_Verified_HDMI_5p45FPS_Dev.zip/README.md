# V172 verified compiled artifacts — development snapshot

Actual PYNQ-Z2 HDMI experiment: 117/117 original MVTec Tile photos correct, 0/33 normal false alarms, 84/84 anomalies and 17/17 cracks detected. Over 254.101 seconds, PL autonomously completed 1386 detections (5.454524 FPS), with both ARM cores checked halted 119 times and no CPU/GPU detection. Frozen model and threshold 10908 are unchanged. Fixed-frame speed separately measures 6.299142 FPS. This repeatedly used development set is not an independent blind test. Sustained 10 FPS, precise crack localization and general painted/mixed materials remain unverified. This is not a final competition submission.

Open report.html for original photographs, actual FPGA input/masks and complete results. hardware/ contains the exact programmed BIT/XSA, software/ contains the matching transport ELF, and model/ contains the frozen model. evidence/ binds identities and all physical results, including all117_direct_raw.zip. The 1-DSP packed acceleration candidate is excluded from this accepted build.

Complete project and rebuild instructions are pinned at https://github.com/fangdut/TileLab-PYNQ-Z2/tree/3e51cd90306f5fa110ef8a281b2d98f999126ef7 . source/texture_integer.cpp is the exact accepted HLS23 source, not the repository's later address-scheduling experiment. hls/accepted_export.zip is its compiled IP; unit_vectors/ are the exact C/RTL fixtures. Vendor IP and board constraints are in the pinned project repository.

Programming uses volatile JTAG only: python source/scripts/texture_v170/program_board.py --hardware hardware --software software --out runtime/program_new

PC Ethernet is 192.168.33.30/24; board is 192.168.33.10:9136. Upload model with the provided board client or rerun validate_board.py against the original dataset. The video experiment tool requires a matching fresh programmed-build regression. Archived boot 142768567 is evidence, not permission to pretend a new boot has already passed those checks. New physical test output directories must be fresh.

HDMI startup gains [260,314,403] apply only to the measured fixed source settings. Recalibrate from the independent gray ramp after changing the display/source color settings; archived color_profile.json contains the original evidence paths. Pixel correction and inference run on FPGA; Python model checks are offline audits. The PC source player only decodes/displays photos. Source player C#/manifest/build scripts are included.

Original code is MIT. MVTec-derived photos/models/evidence retain CC BY-NC-SA 4.0. AMD/Xilinx/Digilent and upstream components retain their licenses.
